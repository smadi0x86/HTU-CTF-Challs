# run Flask server
python3 /ctf/server.py